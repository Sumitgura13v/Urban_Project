
package com.urban.airquality;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UrbanAirQualityApplication {
    public static void main(String[] args) {
        SpringApplication.run(UrbanAirQualityApplication.class, args);
    }
}
