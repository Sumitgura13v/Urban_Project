
package com.urban.airquality.controller;

import com.urban.airquality.model.AirQuality;
import com.urban.airquality.service.AirQualityService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ModelAttribute;

@Controller
public class AirQualityController {

    @Autowired
    private AirQualityService service;

    @GetMapping("/")
    public String index(Model model) {
        model.addAttribute("data", service.getAllData());
        return "index";
    }

    @PostMapping("/add")
    public String addData(@ModelAttribute AirQuality airQuality) {
        service.saveData(airQuality);
        return "redirect:/";
    }
}
