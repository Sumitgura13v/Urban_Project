
package com.urban.airquality.service;

import com.urban.airquality.model.AirQuality;
import com.urban.airquality.repository.AirQualityRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AirQualityService {

    @Autowired
    private AirQualityRepository repository;

    public List<AirQuality> getAllData() {
        return repository.findAll();
    }

    public AirQuality saveData(AirQuality airQuality) {
        return repository.save(airQuality);
    }
}
